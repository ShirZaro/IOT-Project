from datetime import datetime
from sys import path as sysPath
import rticonnextdds_connector as rti
from os import path as osPath
from time import sleep
import random
filepath = osPath.dirname(osPath.realpath(__file__))
connector = rti.Connector("MyParticipantLibrary::Actuator", filepath + "/DDS.xml")
outputDDS = connector.getOutput("Actuator_Publisher::Actuator_Writer")
input_DDS_Temp = connector.getInput("Actuator_Subscriber::Actuator_Reader")
input_DDS_StartStop = connector.getInput("Actuator_StartStop_Subscriber::Actuator_StartStop_Reader")
status = 1                  #initialize the first status for th actuator
outputDDS.instance.setNumber("Actuator_ID", 204799670)
outputDDS.instance.setNumber("status", status)
outputDDS.write()

Start_Stop = 1      #1 if the button in on else 0
Last_status = -1        #start value for first condition
while True:
    outputDDS.instance.setNumber("Actuator_ID", 204799670)
    input_DDS_Temp1.read()       #get temp from sensor 1
    input_DDS_Temp2.read()        #get temp from sensor 2
    input_DDS_StartStop.read()  #get state from start stop button
    numOfSamples_Temp1 = input_DDS_Temp1.samples.getLength()
    numOfSamples_Temp2 = input_DDS_Temp2.samples.getLength()
    numOfSamples_StartStop= input_DDS_StartStop.samples.getLength()
    outputDDS.write()
    if numOfSamples_StartStop>0:        #we got a message from start stop
        Start_Stop =input_DDS_StartStop.samples.getBoolean(numOfSamples_StartStop-1,"On_Off")   #get the newest message
        if Start_Stop==0:
            status = 0
            sleep(0.5)
            if status != Last_status:       #send message only if value changed
                outputDDS.instance.setNumber("status", status)
                outputDDS.write()
                Last_status = status
            print('The machine state is ', status)
            print("receiveda stop command")
        else:
            status=1

    if Start_Stop==1:
        if  numOfSamples_Temp1 > numOfSamples_Temp2:
            size= numOfSamples_Temp2
        else:
            size = numOfSamples_Temp1
       # for j in range(0, size):
          #  Current_temp1 = input_DDS_Temp1.samples.getNumber(j,"Actual_Temp1")
           # Current_temp2 = input_DDS_Temp2.samples.getNumber(j, "Actual_Temp2")
           # temperature_difference =abs(Current_temp1-Current_temp2)
        Current_temp1 = input_DDS_Temp1.samples.getNumber( size -1,"Actual_Temp1")
        Current_temp2 = input_DDS_Temp2.samples.getNumber( size -1, "Actual_Temp2")
        temperature_difference =abs(Current_temp1-Current_temp2)
        if temperature_difference >=7 :
                status = 2
                now = datetime.now()  # current date and time
                time = now.strftime("%H:%M:%S.%f")  # get the hours to miliseconds
                outputDDS.instance.setString("calibration's_Time", time)
                outputDDS.write()
                outputDDS.instance.setString("extreme temp 1", Current_temp1)
                outputDDS.write()
                outputDDS.instance.setString("extreme temp 1",  Current_temp2 )
                outputDDS.write()
                print("calibration is needed")
                Temperature_sensor_3=input_DDS_Temp.take()
                print("Difference measured:",  temperature_difference,"calibration thermometer measurement:",  Temperature_sensor_3)
        else:
                status = 1
        if status != Last_status:   #send message only if value changed
                outputDDS.instance.setNumber("status", status)
                outputDDS.write()
                Last_status = status
            print('The machine state is ',status)

    sleep(1)