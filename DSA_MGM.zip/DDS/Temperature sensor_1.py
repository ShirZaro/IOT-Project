from sys import path as sysPath
import rticonnextdds_connector as rti
from os import path as osPath
from time import sleep
import random
filepath = osPath.dirname(osPath.realpath(__file__))
connector = rti.Connector("MyParticipantLibrary::Temperature_Pub1", filepath + "/DDS.xml")
outputDDS = connector.getOutput("Temp_Publisher1::Temp_Writer1")

while True:
    stutus_actuator=input_DDS_Actuator.read()
    if stutus_actuator==1:
       randomNumb = random.randint(20, 30) #temp between 20-30
       outputDDS.instance.setNumber("Sensor_Number", 1)        #the sensor ID is 1
       outputDDS.instance.setNumber("Actual_Temp", randomNumb)
       outputDDS.write()
       print("The temperature for sensor 1 is ",randomNumb)
       sleep(0.1)            #every second


