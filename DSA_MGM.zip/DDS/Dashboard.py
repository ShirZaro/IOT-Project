import rticonnextdds_connector as rti
from os import path as osPath
from time import sleep
filepath = osPath.dirname(osPath.realpath(__file__))
connector = rti.Connector("MyParticipantLibrary::DashBoard_sub",  filepath + "/DDS.xml")
input_DDS_Temp1 = connector.getInput("Dash_Sub_Temp1::Dash_Reader_Temp1")
input_DDS_Temp2 = connector.getInput("Dash_Sub_Temp2::Dash_Reader_Temp2")
input_DDS_Microphone = connector.getInput("Dash_Sub_Microphone::Dash_Reader_Microphone")
input_DDS_Actuator = connector.getInput("Dash_Sub_Actuator::Dash_Reader_Actuator")



while True:
    allTemp1 = []       #save the last 10 extreme measurements
    allTemp2 = []
    allActuator = []
    sleep(5)                #print every 5 sec
    input_DDS_Temp1.read()
    input_DDS_Temp2.read()
    input_DDS_Microphone.take()
    input_DDS_Actuator.read()
    numOfSamplesTemp1 = input_DDS_Temp1.samples.getLength()
    numOfSamplesTemp2 = input_DDS_Temp2.samples.getLength()
    numOfSamplesActuator = input_DDS_Actuator.samples.getLength()
    numOfSamplesMicrophone= input_DDS_Microphone.samples.getLength()
        #for temperature sensors
    size_1=min(10,numOfSamplesTemp1)
    size_2=min(10,numOfSamplesTemp2)
    for j in range(0, size_1):
        allTemp1.append(input_DDS_Temp1.samples.getNumber(j, "Actual_Temp"))
    for j in range(0,  size_2):
        allTemp2.append(input_DDS_Temp2.samples.getNumber(j, "Actual_Temp"))
    size_3=min(10,numOfSamplesActuator)
    for j in range(0, size_3):
        allActuator.append(input_DDS_Actuator.samples.getNumber(j, "status"))
    if  numOfSamplesMicrophone>0:
        Real_Time = input_DDS_Microphone.samples.getString( numOfSamplesMicrophone-1, "Real_Time")
    else:
        Real_Time=""
    if numOfSamplesActuator>0:
        calibrations_Time=  input_DDS_Actuator.samples.getString(  numOfSamplesActuator-1, "calibration's_Time")
    else:
        calibrations_Time=""
    print(" Microphone:  <", Real_Time, ">")
    print("Actuator:",  allActuator)
    print("Extreme Thermometer 1:",allTemp1)
    print("Extreme Thermometer 2:",allTemp2)
    print("The last calibration's time:",  calibrations_Time)


